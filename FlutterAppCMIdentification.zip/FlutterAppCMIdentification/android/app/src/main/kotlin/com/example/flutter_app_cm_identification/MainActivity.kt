package com.example.flutter_app_cm_identification

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
